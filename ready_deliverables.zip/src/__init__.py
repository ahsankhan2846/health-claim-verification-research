"""Reproducible evaluation pipeline."""
